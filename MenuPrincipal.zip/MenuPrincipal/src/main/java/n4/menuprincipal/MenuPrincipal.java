package n4.menuprincipal;

public class MenuPrincipal {

    public static void main(String[] args) {
        MenuEventosGUI gui = new MenuEventosGUI();
        gui.crearYMostrarGUI();
    }
}
